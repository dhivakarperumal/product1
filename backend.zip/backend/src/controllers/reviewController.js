const db = require('../config/db');
const { getActorUuid } = require('../utils/auditTrail');

// NOTE: use getActorUuid(req.user) from utils/auditTrail for actor UUID

async function getAllReviews(req, res) {
  try {
    // Check if user is super admin
    const isSuperAdmin = req.user && String(req.user.role || '').toLowerCase() === 'super admin';
    
    let whereClause = '';
    let params = [];
    
    // If not super admin, filter by created_by (admin_uuid)
    if (!isSuperAdmin && req.user) {
      const adminUuid = getActorUuid(req.user);
      if (adminUuid) {
        whereClause = ' WHERE created_by = ?';
        params.push(adminUuid);
      }
    }

    const [rows] = await db.query(
      `SELECT * FROM reviews ${whereClause} ORDER BY created_at DESC`,
      params
    );
    res.json(rows);
  } catch (err) {
    console.error('getAllReviews error', err);
    res.status(500).json({ error: 'Query failed' });
  }
}

async function getReviewById(req, res) {
  try {
    const { id } = req.params;
    const idNum = parseInt(id, 10);

    const [rows] = await db.query(
      'SELECT * FROM reviews WHERE id = ?',
      [idNum]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Review not found' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error('getReviewById error', err);
    res.status(500).json({ error: 'Query failed' });
  }
}

async function createReview(req, res) {
  try {
    const { name, rating, message, image, status } = req.body;

    if (!name || !rating) {
      return res.status(400).json({ error: 'Name and rating are required' });
    }

    const createdBy = getActorUuid(req.user) || null;
    const [result] = await db.query(
      `INSERT INTO reviews (name, rating, message, image, status, created_by, updated_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name, Number(rating), message || '', image || '', status ? 1 : 0, createdBy, createdBy]
    );

    const [rows] = await db.query('SELECT * FROM reviews WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error('createReview error', err);
    res.status(500).json({ error: 'Failed to create review' });
  }
}

async function updateReview(req, res) {
  try {
    const { id } = req.params;
    const idNum = parseInt(id, 10);
    const { name, rating, message, image, status } = req.body;

    const updatedBy = getActorUuid(req.user) || null;
    const [result] = await db.query(
      `UPDATE reviews 
       SET name = ?, rating = ?, message = ?, image = ?, status = ?, 
           updated_by = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [name || null, rating ? Number(rating) : null, message || '', image || '', status ? 1 : 0, updatedBy, idNum]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Review not found' });
    }

    const [rows] = await db.query('SELECT * FROM reviews WHERE id = ?', [idNum]);
    res.json(rows[0]);
  } catch (err) {
    console.error('updateReview error', err);
    res.status(500).json({ error: 'Failed to update review' });
  }
}

async function deleteReview(req, res) {
  try {
    const { id } = req.params;
    const idNum = parseInt(id, 10);

    const [result] = await db.query(
      'DELETE FROM reviews WHERE id = ?',
      [idNum]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Review not found' });
    }

    res.json({ message: 'Review deleted successfully' });
  } catch (err) {
    console.error('deleteReview error', err);
    res.status(500).json({ error: 'Failed to delete review' });
  }
}

module.exports = {
  getAllReviews,
  getReviewById,
  createReview,
  updateReview,
  deleteReview,
};
