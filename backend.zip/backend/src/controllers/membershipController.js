const db = require('../config/db');
const { getActorUuid, createAuditTrail, updateAuditTrail } = require('../utils/auditTrail');

// NOTE: use getActorUuid(req.user) from utils/auditTrail for actor UUID (backwards-compatible)

// Resolve members table name (could be 'members' or 'gym_members')
let memberTableName = null;

async function resolveMemberTable() {
  if (memberTableName) return memberTableName;

  const [memberRows] = await db.query("SHOW TABLES LIKE 'members'");
  if (memberRows.length > 0) {
    const [cols] = await db.query("SHOW COLUMNS FROM members LIKE 'member_id'");
    if (cols.length > 0) {
      memberTableName = 'members';
      return memberTableName;
    }
  }

  const [gymRows] = await db.query("SHOW TABLES LIKE 'gym_members'");
  if (gymRows.length > 0) {
    memberTableName = 'gym_members';
    return memberTableName;
  }

  memberTableName = 'members';
  return memberTableName;
}

/* ================= GET ALL MEMBERSHIPS ================= */
async function getAllMemberships(req, res) {
  try {
    // Check if user is super admin
    const isSuperAdmin = req.user && String(req.user.role || '').toLowerCase() === 'super admin';
    const adminUuid = getActorUuid(req.user);
    
    // Get optional admin filter from query params (for super admin)
    const filterAdminUuid = req.query.adminUuid || req.query.admin_uuid || null;
    
    let whereClause = '';
    let params = [];
    
    // If super admin has selected a specific admin to filter by
    if (isSuperAdmin && filterAdminUuid) {
      whereClause = ' WHERE m.created_by = ?';
      params.push(filterAdminUuid);
    }
    // If not super admin, filter by created_by (admin_uuid)
    else if (!isSuperAdmin && req.user) {
      if (adminUuid) {
        whereClause = ' WHERE m.created_by = ?';
        params.push(adminUuid);
      }
    }

    const [rows] = await db.query(`
      SELECT m.*, 
             u.id AS user_id_resolved,
             u.username, 
             u.email AS user_email, 
             u.mobile AS user_mobile, 
             u.role,
             gm.name AS member_name,
             gm.phone AS member_phone,
             gm.email AS gym_member_email,
             s.name AS trainerName,
             s.employee_id AS trainer_emp_id,
             s.email AS trainer_email,
             s.phone AS trainer_phone
      FROM memberships m
      LEFT JOIN users u ON m.userId = u.id OR (m.userId IS NULL AND LOWER(TRIM(m.member_email)) = LOWER(TRIM(u.email)))
      LEFT JOIN members gm ON m.memberId = gm.id
      LEFT JOIN staff s ON m.trainerId = s.id
      ${whereClause}
      ORDER BY m.createdAt DESC
    `, params);
    
    // Post-process to ensure userId is populated
    const processedRows = rows.map(row => {
      if (!row.userId && row.user_id_resolved) {
        row.userId = row.user_id_resolved;
      }
      return row;
    });
    
    res.json(processedRows);
  } catch (error) {
    console.error("Error fetching all memberships:", error);
    res.status(500).json({ error: "Failed to fetch memberships" });
  }
}

/* ================= DELETE MEMBERSHIP ================= */

async function deleteMembership(req, res) {
  try {
    const { id } = req.params;

    const [result] = await db.query(
      "DELETE FROM memberships WHERE id = ?",
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "Membership not found",
      });
    }

    res.json({
      success: true,
      message: "Membership deleted successfully",
    });

  } catch (error) {
    console.error("Delete membership error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to delete membership",
    });
  }
}

/* ================= CREATE MEMBERSHIP ================= */

async function createMembership(req, res) {
  try {
    const {
      userId,
      user_id,
      memberId,
      member_id,
      planId,
      plan_id,
      planName,
      pricePaid,
      price,
      duration,
      startDate,
      endDate,
      paymentId,
      paymentMode,
      status,
    } = req.body;

    // Authorization check
    // Allow admins to create memberships for anyone
    // Allow regular users to create memberships only for themselves
    const isAdmin = req.user && ['admin', 'super admin', 'superadmin'].includes(String(req.user.role || '').toLowerCase());
    // Use userId from JWT (set by buildAuthPayload), fallback to user_id or id
    const currentUserId = req.user?.userId || req.user?.user_id || req.user?.id;

    const requestedUserId = userId || user_id || null;
    const requestedMemberId = memberId || member_id || null;

    // If not admin, user can only create membership for themselves
    if (!isAdmin && (requestedUserId || requestedMemberId)) {
      if (requestedUserId && requestedUserId !== currentUserId) {
        return res.status(403).json({ success: false, message: "You can only create memberships for yourself" });
      }
      if (requestedMemberId && requestedMemberId !== currentUserId) {
        return res.status(403).json({ success: false, message: "You can only create memberships for yourself" });
      }
    }

    const actualPricePaid = pricePaid !== undefined ? pricePaid : price;
    let resolvedUserId = userId || user_id || null;
    let requestedMembershipMemberId = memberId || member_id || null;
    const requestedPlanId = planId || plan_id || null;
    const membersTable = await resolveMemberTable();

    if (!resolvedUserId && !requestedMembershipMemberId) {
      return res.status(400).json({ success: false, message: "userId or memberId is required to create membership" });
    }

    let resolvedMemberId = null;
    let resolvedMemberExternalId = null;
    let resolvedMemberName = null;
    let resolvedMemberEmail = null;
    let resolvedMemberPhone = null;

    if (resolvedUserId) {
      const [validUser] = await db.query(
        "SELECT id, email, mobile, phone FROM users WHERE id = ?",
        [resolvedUserId]
      );

      if (validUser.length === 0) {
        const [memberRow] = await db.query(
          `SELECT id, member_id, name, email, phone FROM ${membersTable} WHERE id = ? OR member_id = ?`,
          [resolvedUserId, resolvedUserId]
        );
        if (memberRow.length > 0) {
          requestedMembershipMemberId = resolvedUserId;
          resolvedMemberId = memberRow[0].id;
          resolvedMemberExternalId = memberRow[0].member_id || String(resolvedUserId) || null;
          resolvedMemberName = memberRow[0].name || null;
          resolvedMemberEmail = memberRow[0].email || null;
          resolvedMemberPhone = memberRow[0].phone || null;
          resolvedUserId = null;
        } else {
          return res.status(400).json({ success: false, message: "Invalid userId for membership" });
        }
      } else {
        const userInfo = validUser[0];
        const userEmail = userInfo.email || null;
        const userPhone = userInfo.mobile || userInfo.phone || null;

        if (userEmail || userPhone) {
          const [memberRow] = await db.query(
            `SELECT id, member_id, name, email, phone FROM ${membersTable} WHERE email = ? OR phone = ? OR member_id = ? LIMIT 1`,
            [userEmail, userPhone, String(resolvedUserId)]
          );
          if (memberRow.length > 0) {
            resolvedMemberId = memberRow[0].id;
            resolvedMemberExternalId = memberRow[0].member_id || null;
            resolvedMemberName = resolvedMemberName || memberRow[0].name || null;
            resolvedMemberEmail = resolvedMemberEmail || memberRow[0].email || null;
            resolvedMemberPhone = resolvedMemberPhone || memberRow[0].phone || null;
          }
        }
      }
    }

    if (requestedMembershipMemberId && !resolvedMemberId) {
      const [validMember] = await db.query(
        `SELECT id, member_id, name, email, phone FROM ${membersTable} WHERE id = ? OR member_id = ?`,
        [requestedMembershipMemberId, requestedMembershipMemberId]
      );
      if (validMember.length === 0) {
        return res.status(400).json({ success: false, message: "Invalid memberId for membership" });
      }
      resolvedMemberId = validMember[0].id;
      resolvedMemberExternalId = validMember[0].member_id || requestedMembershipMemberId || null;
      resolvedMemberName = validMember[0].name || null;
      resolvedMemberEmail = validMember[0].email || null;
      resolvedMemberPhone = validMember[0].phone || null;
    }

    if (!requestedPlanId) {
      return res.status(400).json({ success: false, message: "planId or plan_id is required to create membership" });
    }

    let resolvedPlanExternalId = null;
    let resolvedPlanInternalId = null;
    let resolvedPlanName = planName || null;
    const [validPlan] = await db.query(
      "SELECT id, plan_id, name FROM gym_plans WHERE id = ? OR plan_id = ?",
      [requestedPlanId, requestedPlanId]
    );
    if (validPlan.length === 0) {
      return res.status(400).json({ success: false, message: "Invalid planId for membership" });
    }
    resolvedPlanInternalId = validPlan[0].id;
    resolvedPlanExternalId = validPlan[0].plan_id || null;
    resolvedPlanName = resolvedPlanName || validPlan[0].name || null;

    let finalUserId = resolvedUserId;
    if (resolvedUserId) {
      const [validUser] = await db.query(
        "SELECT id FROM users WHERE id = ?",
        [resolvedUserId]
      );
      if (validUser.length === 0) {
        return res.status(400).json({ success: false, message: "Invalid userId for membership" });
      }
    } else if (resolvedMemberId) {
      const [linkedUser] = await db.query(
        "SELECT id FROM users WHERE email = ? OR mobile = ? LIMIT 1",
        [resolvedMemberEmail, resolvedMemberPhone]
      );
      if (linkedUser.length > 0) {
        finalUserId = linkedUser[0].id;
      }
    }

    // Helper to validate and normalize UUID-like strings (reject numeric-only values)
    const normalizeUuid = (value) => {
      if (typeof value !== 'string') return null;
      const trimmed = value.trim();
      if (trimmed.length === 0) return null;
      // Reject numeric-only values like "5" or "123"
      if (/^\d+$/.test(trimmed)) return null;
      return trimmed;
    };

    // Set created_by and updated_by to member_id if user is a member, else fallback to UUID
    let createdBy = null;
    let updatedBy = null;
    if (req.user && req.user.role && String(req.user.role).toLowerCase() === 'member') {
      // Try to get member_id from members table using userId from JWT
      const memberUserId = req.user.userId || req.user.user_id || req.user.id;
      const [memberRow] = await db.query(
        `SELECT member_id FROM ${membersTable} WHERE id = ?`,
        [memberUserId]
      );
      const memberIdValue = memberRow.length > 0 ? normalizeUuid(memberRow[0].member_id) : null;
      if (memberIdValue) {
        createdBy = memberIdValue;
        updatedBy = memberIdValue;
      } else {
        // fallback to UUID if not found or not a valid UUID
        const auditTrail = createAuditTrail(req.user);
        createdBy = auditTrail.created_by;
        updatedBy = auditTrail.updated_by;
      }
    } else {
      const auditTrail = createAuditTrail(req.user);
      createdBy = auditTrail.created_by;
      updatedBy = auditTrail.updated_by;
    }


    const query = `
      INSERT INTO memberships
      (userId, memberId, member_id, member_name, member_email, planId, plan_id, planName, pricePaid, duration, startDate, endDate, paymentId, paymentMode, status, created_by, updated_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
      finalUserId,
      resolvedMemberId,
      resolvedMemberExternalId,
      resolvedMemberName,
      resolvedMemberEmail,
      resolvedPlanInternalId,
      resolvedPlanExternalId,
      resolvedPlanName,
      actualPricePaid,
      duration,
      startDate,
      endDate,
      paymentId || null,
      paymentMode || null,
      status || 'active',
      createdBy,
      updatedBy,
    ];

    const [result] = await db.query(query, values);

    res.status(201).json({
      success: true,
      membershipId: result.insertId,
    });

  } catch (error) {
    console.error("Create membership error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to create membership",
    });
  }
}

/* ================= GET USER MEMBERSHIPS ================= */

async function getUserMemberships(req, res) {
  try {
    const { userId } = req.params;

    const [rows] = await db.query(
      `SELECT * FROM memberships
       WHERE userId = ?
          OR memberId = ?
          OR member_id = ?
          OR member_email = ?
       ORDER BY createdAt DESC`,
      [userId, userId, userId, userId]
    );

    res.json(rows);

  } catch (error) {
    console.error("Fetch memberships error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch memberships",
    });
  }
}

/* ================= GET MEMBERSHIP BY ID ================= */

async function getMembershipById(req, res) {
  try {
    const { id } = req.params;

    const [rows] = await db.query(
      "SELECT * FROM memberships WHERE id = ?",
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        message: "Membership not found",
      });
    }

    res.json(rows[0]);

  } catch (error) {
    console.error("Fetch membership error:", error);
    res.status(500).json({
      message: "Server error",
    });
  }
}

/* ================= UPDATE MEMBERSHIP ================= */
async function updateMembership(req, res) {
  try {
    const { id } = req.params;
    const body = req.body || {};

    // Get audit trail data (updated_by with admin UUID)
    const auditTrail = updateAuditTrail(req.user);

    // Map incoming fields to DB columns
    const fieldMap = {
      userId: 'userId',
      user_id: 'userId',
      memberId: 'memberId',
      member_id: 'member_id',
      member_name: 'member_name',
      member_email: 'member_email',
      planId: 'planId',
      plan_id: 'plan_id',
      planName: 'planName',
      pricePaid: 'pricePaid',
      price: 'pricePaid',
      duration: 'duration',
      startDate: 'startDate',
      endDate: 'endDate',
      paymentId: 'paymentId',
      paymentMode: 'paymentMode',
      status: 'status',
      isEMI: 'isEMI',
      emiMonths: 'emiMonths',
      totalAmount: 'totalAmount',
      trainerId: 'trainerId',
      trainer_id: 'trainerId'
    };

    const setClauses = [];
    const params = [];

    Object.keys(fieldMap).forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(body, key) && body[key] !== undefined) {
        setClauses.push(`${fieldMap[key]} = ?`);
        params.push(body[key]);
      }
    });

    // Always update updated_by
    setClauses.push('updated_by = ?');
    params.push(auditTrail.updated_by);

    if (setClauses.length === 1) {
      // only updated_by was set => nothing meaningful to update
      return res.status(400).json({ success: false, message: 'No updatable fields provided' });
    }

    const sql = `UPDATE memberships SET ${setClauses.join(', ')} WHERE id = ?`;
    params.push(id);

    const [result] = await db.query(sql, params);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Membership not found' });
    }

    // If startDate or endDate provided, also update the member's join/expiry dates
    try {
      const membersTable = await resolveMemberTable();
      const joinDate = body.startDate || body.start_date || null;
      const expiryDate = body.endDate || body.end_date || null;

      if ((joinDate || expiryDate) && membersTable) {
        // Prefer explicit memberId/member_id, else try userId
        const memberIdValue = body.memberId || body.member_id || null;
        const userIdValue = body.userId || body.user_id || null;

        const updateClauses = [];
        const updateParams = [];
        if (joinDate !== null && joinDate !== undefined) {
          updateClauses.push('join_date = ?');
          updateParams.push(joinDate);
        }
        if (expiryDate !== null && expiryDate !== undefined) {
          updateClauses.push('expiry_date = ?');
          updateParams.push(expiryDate);
        }

        if (updateClauses.length > 0) {
          // always set updated_by
          updateClauses.push('updated_by = ?');
          updateParams.push(auditTrail.updated_by);

          let whereSql = '';
          const whereParams = [];
          if (memberIdValue) {
            // try numeric id and member_id string
            whereSql = 'WHERE id = ? OR member_id = ?';
            whereParams.push(memberIdValue, memberIdValue);
          } else if (userIdValue) {
            whereSql = 'WHERE user_id = ? OR id = ?';
            whereParams.push(userIdValue, userIdValue);
          }

          if (whereSql) {
            const updateSql = `UPDATE ${membersTable} SET ${updateClauses.join(', ')} ${whereSql} LIMIT 1`;
            await db.query(updateSql, [...updateParams, ...whereParams]);
          }
        }
      }
    } catch (err) {
      console.error('Failed to update member join/expiry dates after membership update:', err);
    }

    res.json({ success: true, message: 'Membership updated successfully' });
  } catch (error) {
    console.error("Update membership error:", error);
    res.status(500).json({ success: false, message: "Failed to update membership" });
  }
}

/* ================= GET EXPIRING SOON ================= */
async function getExpiringSoon(req, res) {
  try {
    const { trainerUserId, userId, daysAhead = 3 } = req.query;
    let staffId = null;

    if (trainerUserId) {
      const [userRows] = await db.query(
        'SELECT email, username FROM users WHERE id = ?',
        [trainerUserId]
      );
      if (userRows.length > 0) {
        const u = userRows[0];
        const [staffRows] = await db.query(
          'SELECT id FROM staff WHERE email = ? OR username = ? LIMIT 1',
          [u.email, u.username]
        );
        if (staffRows.length > 0) staffId = staffRows[0].id;
      }
    }

    let sql = `
      SELECT m.*, 
             u.username, 
             u.email
      FROM memberships m
      LEFT JOIN users u ON m.userId = u.id
    `;

    const conditions = ['m.status = \'active\'', 'm.endDate >= CURDATE()', 'm.endDate <= DATE_ADD(CURDATE(), INTERVAL ? DAY)'];
    const params = [daysAhead];

    if (staffId) {
      conditions.push('m.trainerId = ?');
      params.unshift(staffId);
    }

    sql += ` WHERE ${conditions.join(' AND ')}`;

    if (!staffId && userId) {
      sql += ` AND (m.userId = ? OR m.memberId = ? OR m.member_id = ? OR m.member_email = ?)`;
      params.push(userId, userId, userId, userId);
    }

    sql += ` ORDER BY m.endDate ASC `;

    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (error) {
    console.error("Error fetching expiring memberships:", error);
    console.error(error.stack || error);
    res.status(500).json({ error: "Failed to fetch alerts", details: error.message });
  }
}

/* ================= GET TODAY REGISTRATIONS ================= */
async function getTodayRegistrations(req, res) {
  try {
    console.log('getTodayRegistrations called');
    const [rows] = await db.query(`
      SELECT m.*, 
             u.username, 
             u.email
      FROM memberships m
      LEFT JOIN users u ON m.userId = u.id
      WHERE DATE(m.createdAt) = CURDATE()
      ORDER BY m.createdAt DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error("Error fetching today's registrations:", error);
    console.error(error.stack || error);
    res.status(500).json({ error: "Failed to fetch registrations", details: error.message });
  }
}

/* ================= EMI FUNCTIONS ================= */

// Helper function to calculate EMI
function calculateEMIAmount(principal, months) {
  if (months <= 0 || principal <= 0) return 0;
  return Math.ceil((principal / months) * 100) / 100; // Round up to nearest paise
}

// Create EMI schedule for a membership
async function createEMISchedule(req, res) {
  try {
    const { membershipId, emiMonths } = req.body;

    if (!membershipId || !emiMonths || emiMonths < 2) {
      return res.status(400).json({ success: false, message: "Valid membershipId and emiMonths (min 2) required" });
    }

    // Get membership details
    const [membership] = await db.query(
      "SELECT * FROM memberships WHERE id = ?",
      [membershipId]
    );

    if (membership.length === 0) {
      return res.status(404).json({ success: false, message: "Membership not found" });
    }

    const m = membership[0];
    const totalAmount = m.totalAmount || m.pricePaid;
    const emiAmount = calculateEMIAmount(totalAmount, emiMonths);
    const emiStartDate = new Date(m.startDate);

    // Update membership with EMI details
    await db.query(
      `UPDATE memberships 
       SET isEMI = 1, emiMonths = ?, emiAmount = ?, emiStartDate = ?, totalAmount = ?, nextEMIDate = ?
       WHERE id = ?`,
      [emiMonths, emiAmount, m.startDate, totalAmount, m.startDate, membershipId]
    );

    // Create EMI payments schedule
    const today = new Date();
    const payments = [];

    for (let i = 1; i <= emiMonths; i++) {
      const dueDate = new Date(emiStartDate);
      dueDate.setMonth(dueDate.getMonth() + i);

      let emiPaymentAmount = emiAmount;
      if (i === emiMonths) {
        // Last payment - adjust for rounding differences
        const totalPaid = emiAmount * (emiMonths - 1);
        emiPaymentAmount = totalAmount - totalPaid;
      }

      const [result] = await db.query(
        `INSERT INTO emi_payments 
         (membershipId, installmentNumber, amount, dueDate, status)
         VALUES (?, ?, ?, ?, ?)`,
        [membershipId, i, emiPaymentAmount, dueDate, 'pending']
      );

      payments.push({
        id: result.insertId,
        installmentNumber: i,
        amount: emiPaymentAmount,
        dueDate: dueDate.toISOString().split('T')[0],
        status: 'pending'
      });
    }

    res.json({
      success: true,
      membershipId,
      emiAmount,
      emiMonths,
      totalAmount,
      payments
    });

  } catch (error) {
    console.error("Create EMI schedule error:", error);
    res.status(500).json({ success: false, message: "Failed to create EMI schedule" });
  }
}

// Get EMI payments for a membership
async function getEMIPayments(req, res) {
  try {
    const { membershipId } = req.params;

    const [payments] = await db.query(
      `SELECT * FROM emi_payments 
       WHERE membershipId = ?
       ORDER BY installmentNumber ASC`,
      [membershipId]
    );

    res.json(payments);

  } catch (error) {
    console.error("Get EMI payments error:", error);
    res.status(500).json({ success: false, message: "Failed to fetch EMI payments" });
  }
}

// Get upcoming EMI payments (for notifications)
async function getUpcomingEMIPayments(req, res) {
  try {
    const { daysAhead = 7, userId } = req.query;

    let query = `SELECT ep.*, m.*, gm.name AS member_name, gm.email AS member_email, gm.phone AS member_phone
       FROM emi_payments ep
       JOIN memberships m ON ep.membershipId = m.id
       LEFT JOIN members gm ON m.memberId = gm.id
       WHERE ep.status = 'pending'
       AND ep.dueDate >= CURDATE()
       AND ep.dueDate <= DATE_ADD(CURDATE(), INTERVAL ? DAY)`;

    const params = [daysAhead];
    if (userId) {
      query += ` AND (m.userId = ? OR m.memberId = ? OR m.member_id = ? OR m.member_email = ?)`;
      params.push(userId, userId, userId, userId);
    }

    query += ` ORDER BY ep.dueDate ASC`;

    const [payments] = await db.query(query, params);

    res.json(payments);

  } catch (error) {
    console.error("Get upcoming EMI payments error:", error);
    res.status(500).json({ success: false, message: "Failed to fetch upcoming EMI payments" });
  }
}

// Update EMI payment status
async function updateEMIPayment(req, res) {
  try {
    const { paymentId } = req.params;
    const { status, paymentMethod, paidDate } = req.body;

    if (!status || !['pending', 'completed', 'overdue', 'cancelled'].includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid status" });
    }

    const [result] = await db.query(
      `UPDATE emi_payments 
       SET status = ?, paymentMethod = ?, paidDate = ?, updatedAt = NOW()
       WHERE id = ?`,
      [status, paymentMethod || null, paidDate || null, paymentId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: "Payment not found" });
    }

    // Update membership nextEMIDate
    const [payment] = await db.query(
      "SELECT membershipId FROM emi_payments WHERE id = ?",
      [paymentId]
    );

    if (payment.length > 0) {
      const [nextPayment] = await db.query(
        `SELECT dueDate FROM emi_payments 
         WHERE membershipId = ? AND status = 'pending'
         ORDER BY dueDate ASC LIMIT 1`,
        [payment[0].membershipId]
      );

      if (nextPayment.length > 0) {
        await db.query(
          "UPDATE memberships SET nextEMIDate = ? WHERE id = ?",
          [nextPayment[0].dueDate, payment[0].membershipId]
        );
      }
    }

    res.json({ success: true, message: "EMI payment updated successfully" });

  } catch (error) {
    console.error("Update EMI payment error:", error);
    res.status(500).json({ success: false, message: "Failed to update EMI payment" });
  }
}

// Get EMI status for membership
async function getEMIStatus(req, res) {
  try {
    const { membershipId } = req.params;

    const [membership] = await db.query(
      `SELECT id, isEMI, emiMonths, emiAmount, emiStartDate, totalAmount, nextEMIDate, pricePaid
       FROM memberships
       WHERE id = ?`,
      [membershipId]
    );

    if (membership.length === 0) {
      return res.status(404).json({ success: false, message: "Membership not found" });
    }

    const m = membership[0];

    if (!m.isEMI) {
      return res.json({ success: true, isEMI: false, message: "This is not an EMI membership" });
    }

    const [payments] = await db.query(
      `SELECT COUNT(*) as total, 
              SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
              SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
              SUM(CASE WHEN status = 'overdue' THEN 1 ELSE 0 END) as overdue
       FROM emi_payments
       WHERE membershipId = ?`,
      [membershipId]
    );

    res.json({
      success: true,
      isEMI: true,
      emiMonths: m.emiMonths,
      emiAmount: m.emiAmount,
      totalAmount: m.totalAmount,
      nextEMIDate: m.nextEMIDate,
      stats: payments[0]
    });

  } catch (error) {
    console.error("Get EMI status error:", error);
    res.status(500).json({ success: false, message: "Failed to fetch EMI status" });
  }
}

module.exports = {
  createMembership,
  getUserMemberships,
  getMembershipById,
  getAllMemberships,
  getExpiringSoon,
  getTodayRegistrations,
  updateMembership,
  deleteMembership,
  createEMISchedule,
  getEMIPayments,
  getUpcomingEMIPayments,
  updateEMIPayment,
  getEMIStatus,
};